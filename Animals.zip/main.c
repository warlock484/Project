#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Node declaration
 struct Node {
    char *data;
    struct Node *left;
    struct Node *right;
};
//Creating node
struct Node *newNode(char *data) {
    struct Node *node = (struct Node *)malloc(sizeof(struct Node));
    node->data = (char *)malloc(strlen(data) + 1);
    strcpy(node->data, data);
    node->left = node->right = NULL;	
    return node;
}
//function for the game creation
void play(struct Node *root) {
    struct Node *current = root;
    char answer[20];

    while (1) {
        if (current->left == NULL && current->right == NULL) {
            printf("Is it a %s? \n", current->data);
            scanf("%s", answer);
            // Quessing the correct animal
            if (strcmp(answer, "yes") == 0) {
                printf("I win!\n");
                break;
            } else {
            	// Adding the new animal with a related question in the binary tree
                printf("What is it?\n ");
                char newAnimals[50];
                char newQuestion[50];
                scanf("%s", newAnimals);
                printf("What's a question to distinguish a %s from a %s?\n ", newAnimals, current->data);
                scanf("%s", newQuestion);
                struct Node *newAnimalsNode = newNode(newAnimals);
                struct Node *newQuestionNode = newNode(newQuestion);
                current->data = (char *)malloc(strlen(newQuestion) + 1);
                strcpy(current->data, newQuestion);
                current->left = newAnimalsNode;
                current->right = newQuestionNode;
            }
        }

        printf("%s?\n ", current->data);
        scanf("%s", answer);

        if (strcmp(answer, "yes") == 0)
            current = current->left;
        else
            current = current->right;
    }
}
//main
int main() {
	//introduction
    struct Node *root = newNode("Is it a mammal");
    root->left = newNode("dog");
    root->right = newNode("Is it a bird");
    root->right->left = newNode("parrot");
    root->right->right = newNode("snake");
	int a =1;
	
    char userInput[5];
    while(1){
    	
    	if(a==1){
    		//Introduction
    		printf("Welcome to the game of animal\n");
    		printf("Think  of an animal and then be prepared to answer some yes or no question\n");
    		printf("Which are gonna be used to guess the animal\n");
    		printf("When ready press 1\n");
    		int b=fgetc(stdin);
    		play(root);
    		a=0;
		}else{
		
		//Play again or finish
        printf("Do you want to play again? (yes/no)\n");
        scanf("%s", userInput);
        if(strcmp(userInput, "yes") == 0){
        
            play(root);
        }else if(strcmp(userInput, "no") == 0){
            printf("Thank you for playing!\n");
            break;
        }else{
            printf("Invalid input, please enter yes or no\n");
        }
		
	
    }
		}
    return 0;
}
